package run;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		Grammar grammar = new Grammar("grammar.txt");
 //		Grammar grammar = new Grammar("program.txt");
		Parser parser = new Parser(grammar);

		System.out.println("FIRST");
		System.out.println(parser.getFirst());
		System.out.println();
		System.out.println("FOLLOW");
		System.out.println(parser.getFollow());
		System.out.println();

		try {
			parser.computeParsingTable();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}

		
		if( parser.parseSequence(new ArrayList<>() {
			{
				add("a");
				add("+");
				add("(");
				add("a");
				add("+");
				add("a");
				add(")");
			}
		}) == true) {
			System.out.println( " Sequence is accepted");
		}else
			System.out.println( " Sequence is not accepted");
		
		


		StringBuilder builder = new StringBuilder(" ");

		ArrayList<String> terminals = grammar.getTerminals();
		terminals.add("$");

		builder.append("\t" + "       ");
		for (String elem : terminals) {
			builder.append(elem).append("\t" + "\t" +  "             ");
		}
		builder.append("\n");

		for (String nonTerminal : grammar.getNonTerminals()) {
			builder.append(nonTerminal);
			for (String terminal : terminals) {
				Pair pair = new Pair(nonTerminal, terminal);
				builder.append("\t").append(parser.getParsingTable().get(pair)).append("\t"+"        ");
			}
			builder.append("\n");
		}
		
		System.out.println();
		System.out.println("PARSING TABLE:");
		System.out.println(builder.toString());
		System.out.println();
	}

}
