package run;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.Stack;

public class Parser {
	private final Grammar grammar;
	private HashMap<String, ArrayList<String>> first;
	private HashMap<String, ArrayList<String>> follow;
	private HashMap<Pair, ParsingTableCell> parsingTable;
	Stack<String> inputStack = new Stack<>();
	Stack<String> workingStack = new Stack<>();
	Stack<String> output = new Stack<>();

	public Parser(Grammar grammar) {
		this.grammar = grammar;

		this.first = new HashMap<>();
		this.computeFirst();

		this.follow = new HashMap<>();
		this.computeFollow();

		this.parsingTable = new HashMap<>();
	}

	private void computeFirst() {
		ArrayList<HashMap<String, ArrayList<String>>> table = new ArrayList<>();

		HashMap<String, ArrayList<String>> currentColumn = new HashMap<>();

		// get the nonterminals and their productions
		for (String nonTerminal : this.grammar.getNonTerminals()) {
			ArrayList<ArrayList<String>> productionsForNonTerminal = this.grammar.getProductions().get(nonTerminal);
			ArrayList<String> var = new ArrayList<>();
			for (ArrayList<String> productionForNonTerminal : productionsForNonTerminal)

				// If X is terminal, then First(X) is X
				// If X -> $ is a production, then add to First(X).
				if (grammar.getTerminals().contains(productionForNonTerminal.get(0))
						|| productionForNonTerminal.get(0).equals("epsilon")) {
					var.add(productionForNonTerminal.get(0));
				}
			currentColumn.put(nonTerminal, this.toSet(var));
		}

		table.add(currentColumn);
		int index = 0;

		// Thus, if X is the current non-terminal
		// and a is the next symbol on the input, then we want to look
		// at the r.h.s. of the production rules for X and choose the one whose FIRST
		// set contains a.
		{
			HashMap<String, ArrayList<String>> newColumn = new HashMap<>();
			for (String nonTerminal : this.grammar.getNonTerminals()) {
				ArrayList<ArrayList<String>> productionsForNonTerminal = this.grammar.getProductions().get(nonTerminal);
				ArrayList<String> rhsNonTerminals = new ArrayList<>();
				String rhsTerminals = null;
				ArrayList<String> toAdd = new ArrayList<>(table.get(0).get(nonTerminal));
				for (ArrayList<String> productionForNonTerminal : productionsForNonTerminal) {
					for (String symbol : productionForNonTerminal)
						if (this.grammar.getNonTerminals().contains(symbol))
							rhsNonTerminals.add(symbol);
						else {
							rhsTerminals = symbol;
							break;
						}
					toAdd.addAll(toSet(multipleConcatenation(table.get(0), rhsNonTerminals, rhsTerminals)));
				}

				newColumn.put(nonTerminal, toAdd);
			}
			index++;
			table.add(newColumn);
		}

		// check the same with the next production in the case the nonterminal has it
		while (!table.get(index).equals(table.get(index - 1))) {
			HashMap<String, ArrayList<String>> newColumn = new HashMap<>();
			for (String nonTerminal : this.grammar.getNonTerminals()) {

				ArrayList<ArrayList<String>> productionsForNonTerminal = this.grammar.getProductions().get(nonTerminal);
				ArrayList<String> rhsNonTerminals = new ArrayList<>();
				String rhsTerminals = null;
				ArrayList<String> toAdd = new ArrayList<>(table.get(index).get(nonTerminal));
				for (ArrayList<String> productionForNonTerminal : productionsForNonTerminal) {
					for (String symbol : productionForNonTerminal)
						if (this.grammar.getNonTerminals().contains(symbol))
							rhsNonTerminals.add(symbol);
						else {
							rhsTerminals = symbol;
							break;
						}
					toAdd.addAll(multipleConcatenation(table.get(index), rhsNonTerminals, rhsTerminals));
				}
				newColumn.put(nonTerminal, toSet(toAdd));
			}
			index++;
			table.add(newColumn);
		}
		this.first = table.get(table.size() - 1);
	}

	private void computeFollow() {
		ArrayList<HashMap<String, ArrayList<String>>> table = new ArrayList<>();

		HashMap<String, ArrayList<String>> currentColumn = new HashMap<>();
		for (String nonTerminal : this.grammar.getNonTerminals()) {
			ArrayList<String> data = new ArrayList<>();
			// is S is the start symbol, then put $ into FOLLOW(S)
			if (nonTerminal.equals(grammar.getStartingSymbol())) {
				data.add("epsilon");
			}
			currentColumn.put(nonTerminal, data);
		}

		table.add(currentColumn);
		int index = 0;

//		Examine all rules of the form A->aBb then
//		FIRST(b) is in FOLLOW(X)	

//		 Check that character that follows B in the production rule is same as the current character in the input
//		in order to vanish this non-terminal 
		
//		also could be done if the nonterminal arrives to epsilon
		{
			HashMap<String, ArrayList<String>> newColumn = new HashMap<>();
			for (String nonTerminal : this.grammar.getNonTerminals()) {
				ArrayList<String> toAdd = new ArrayList<>(table.get(index).get(nonTerminal));
				newColumn.put(nonTerminal, toAdd);
			}

			for (String nonTerminal : this.grammar.getNonTerminals()) {

				ArrayList<ArrayList<String>> productionsForNonTerminal = this.grammar.getProductions().get(nonTerminal);

				for (ArrayList<String> productionForNonTerminal : productionsForNonTerminal) {
					for (int i = 0; i < productionForNonTerminal.size(); i++) {
						String symbol = productionForNonTerminal.get(i);
						if (this.grammar.getNonTerminals().contains(symbol)) {
							if (i == productionForNonTerminal.size() - 1) {
								ArrayList<String> var = new ArrayList<>(table.get(index).get(nonTerminal)),
										aux = new ArrayList<>(newColumn.get(symbol));
								aux.addAll(var);
								aux = toSet(aux);
								newColumn.remove(symbol);
								newColumn.put(symbol, aux);
							} else {
								if (this.grammar.getNonTerminals().contains(productionForNonTerminal.get(i + 1))) {
									ArrayList<String> nonTerminals = new ArrayList<>();
									String terminal = null;
									for (int j = i + 1; j < productionForNonTerminal.size(); j++)
										if (this.grammar.getNonTerminals().contains(productionForNonTerminal.get(j)))
											nonTerminals.add(productionForNonTerminal.get(j));
										else {
											terminal = productionForNonTerminal.get(j);
											break;
										}

									ArrayList<String> firstOfWhatIsAfter = multipleConcatenation(this.first,
											nonTerminals, terminal);
									if (firstOfWhatIsAfter.contains("epsilon")) {
										ArrayList<String> var = new ArrayList<>(table.get(index).get(nonTerminal));
										ArrayList<String> aux = new ArrayList<>(newColumn.get(symbol));
										aux.addAll(var);
										aux = toSet(aux);
										newColumn.remove(symbol);
										newColumn.put(symbol, aux);

									}
									ArrayList<String> f = new ArrayList<>(firstOfWhatIsAfter);
									f.remove("epsilon");
									ArrayList<String> aux = new ArrayList<>(newColumn.get(symbol));
									aux.addAll(f);
									aux = toSet(aux);
									newColumn.remove(symbol);
									newColumn.put(symbol, aux);
								} else {
									ArrayList<String> f = new ArrayList<>();
									f.add(productionForNonTerminal.get(i + 1));

									f.remove("epsilon");
									ArrayList<String> aux = new ArrayList<>(newColumn.get(symbol));
									aux.addAll(f);
									aux = toSet(aux);
									newColumn.remove(symbol);
									newColumn.put(symbol, aux);
								}
							}
						}
					}
				}

			}
			index++;
			table.add(newColumn);
		}

		while (!table.get(index).equals(table.get(index - 1))) {
			HashMap<String, ArrayList<String>> newColumn = new HashMap<>();
			for (String nonTerminal : this.grammar.getNonTerminals()) {
				ArrayList<String> toAdd = new ArrayList<>(table.get(index).get(nonTerminal));
				newColumn.put(nonTerminal, toAdd);
			}

			for (String nonTerminal : this.grammar.getNonTerminals()) {

				ArrayList<ArrayList<String>> productionsForNonTerminal = this.grammar.getProductions().get(nonTerminal);

				for (ArrayList<String> productionForNonTerminal : productionsForNonTerminal) {
					for (int i = 0; i < productionForNonTerminal.size(); i++) {
						String symbol = productionForNonTerminal.get(i);
						if (this.grammar.getNonTerminals().contains(symbol)) {
							if (i == productionForNonTerminal.size() - 1) {
								ArrayList<String> var = new ArrayList<>(table.get(index).get(nonTerminal)); // FOLLOW(nonTerminal)
								ArrayList<String> aux = new ArrayList<>(newColumn.get(symbol));
								aux.addAll(var);
								aux = toSet(aux);
								newColumn.remove(symbol);
								newColumn.put(symbol, aux);
							}

							else {

								if (this.grammar.getNonTerminals().contains(productionForNonTerminal.get(i + 1))) {

									ArrayList<String> nonTerminals = new ArrayList<>();
									String terminal = null;
									for (int j = i + 1; j < productionForNonTerminal.size(); j++)
										if (this.grammar.getNonTerminals().contains(productionForNonTerminal.get(j)))
											nonTerminals.add(productionForNonTerminal.get(j));
										else {
											terminal = productionForNonTerminal.get(j);
											break;
										}

									ArrayList<String> firstOfWhatIsAfter = multipleConcatenation(this.first,
											nonTerminals, terminal);

									if (firstOfWhatIsAfter.contains("epsilon")) {

										ArrayList<String> var = new ArrayList<>(table.get(index).get(nonTerminal)); // FOLLOW(nonTerminal)
										ArrayList<String> aux = new ArrayList<>(newColumn.get(symbol));
										aux.addAll(var);
										aux = toSet(aux);
										newColumn.remove(symbol);
										newColumn.put(symbol, aux);

									}

									ArrayList<String> f = new ArrayList<>(firstOfWhatIsAfter);
									f.remove("epsilon");
									ArrayList<String> aux = new ArrayList<>(newColumn.get(symbol));
									aux.addAll(f);
									aux = toSet(aux);
									newColumn.remove(symbol);
									newColumn.put(symbol, aux);
								}

								else {
									ArrayList<String> f = new ArrayList<>();
									f.add(productionForNonTerminal.get(i + 1));
									// if that terminal is epsilon, we do not add anything
									f.remove("epsilon");
									ArrayList<String> aux = new ArrayList<>(newColumn.get(symbol));
									aux.addAll(f);
									aux = toSet(aux);
									newColumn.remove(symbol);
									newColumn.put(symbol, aux);
								}
							}
						}
					}
				}

			}
			index++;
			table.add(newColumn);

		}
		this.follow = table.get(table.size() - 1);
	}

	public void computeParsingTable() throws IllegalAccessException {
		ArrayList<String> allSymbols = (ArrayList<String>) grammar.getNonTerminals().clone();
		allSymbols.addAll(grammar.getTerminals());
		allSymbols.add("$");
		
		
		for (String nonTerminal : allSymbols) {
			for (String terminal : grammar.getTerminals()) {
				if (nonTerminal.equals(terminal)) {
					ArrayList<String> pop = new ArrayList<String>();
					pop.add("pop");
					parsingTable.put(new Pair(nonTerminal, terminal), new ParsingTableCell(pop, 0));
				} else {
					parsingTable.put(new Pair(nonTerminal, terminal), null);
				}
			}
			if (nonTerminal.equals("$")) {
				ArrayList<String> acc = new ArrayList<String>();
				acc.add("acc");
				parsingTable.put(new Pair(nonTerminal, "$"), new ParsingTableCell(acc, 0));
			} else {
				parsingTable.put(new Pair(nonTerminal, "$"), null);
			}
		}

		HashMap<String, ArrayList<ArrayList<String>>> productions = this.grammar.getProductions();

		int prodIndex = 1;

		
		for (String nonTerminal : grammar.getNonTerminals()) {
			ArrayList<ArrayList<String>> nonTerminalProds = productions.get(nonTerminal);
			for (ArrayList<String> prod : nonTerminalProds) {

				if (prod.get(0).equals("epsilon")) {
					ArrayList<String> follow = this.follow.get(nonTerminal);
					for (String elem : follow) {
						elem = elem.equals("epsilon") ? "$" : elem;
						parsingTable.put(new Pair(nonTerminal, elem), new ParsingTableCell(prod, prodIndex));
					}
				} else {
					ArrayList<String> firstOfSeq = firstOfSequence(prod);

					for (String elem : firstOfSeq) {
						parsingTable.put(new Pair(nonTerminal, elem), new ParsingTableCell(prod, prodIndex));
					}
				}
				prodIndex++;
			}
		}
	}

	public HashMap<String, ArrayList<String>> getFirst() {
		return first;
	}

	public HashMap<String, ArrayList<String>> getFollow() {
		return follow;
	}

	public HashMap<Pair, ParsingTableCell> getParsingTable() {
		return parsingTable;
	}

	public boolean parseSequence(ArrayList<String> sequence) {
		initializeStacks(sequence);

		boolean go = true;
		boolean result = true;

		while (go) {
			String headOfInputStack = inputStack.peek();
			String headOfWorkingStack = workingStack.peek();

			if (headOfWorkingStack.equals("$") && headOfInputStack.equals("$")) {

				System.out.println("PARSING SEQUENCE   =>   " + sequence);
				System.out.println(output);
				System.out.println();
				return result;
			}

			Pair pair = new Pair(headOfWorkingStack, headOfInputStack);
			ParsingTableCell cell = this.parsingTable.get(pair);
			if (cell == null) {
				pair = new Pair(headOfWorkingStack, "epsilon");
				cell = this.parsingTable.get(pair);
				if (cell != null) {
					this.workingStack.pop();
					continue;
				}
			}

			if (cell == null) {
				go = false;
				result = false;
			} else {
				ArrayList<String> seq = cell.getSequence();
				int productionNumber = cell.getProductionNumber();

				if (productionNumber == 0 && seq.get(0).equals("acc")) {
					go = false;
				} else if (productionNumber == 0 && seq.get(0).equals("pop")) {
					workingStack.pop();
					inputStack.pop();
				} else {
					workingStack.pop();
					if (!seq.get(0).equals("epsilon")) {
						for (int i = seq.size() - 1; i >= 0; i--)
							workingStack.push(seq.get(i));

					}
					output.push(String.valueOf(productionNumber));
				}
			}

		}

		System.out.println(output);
		return result;

	}

	public void initializeStacks(ArrayList<String> sequence) {
		inputStack.clear();
		inputStack.push("$");
		for (int i = sequence.size() - 1; i >= 0; i--)
			inputStack.push(sequence.get(i));

		workingStack.clear();
		workingStack.push("$");
		workingStack.push(grammar.getStartingSymbol());

		output.clear();
		output.push("epsilon");
	}

	private ArrayList<String> multipleConcatenation(HashMap<String, ArrayList<String>> previousColumn,
			ArrayList<String> rhsNonTerminals, String rhsTerminal) {
		ArrayList<String> concatenation = new ArrayList<>();
		if (rhsNonTerminals.size() == 0)
			return concatenation;
		if (rhsNonTerminals.size() == 1) {
			return previousColumn.get(rhsNonTerminals.get(0));
		}
		int step = 0;
		boolean allEpsilon = true;
		for (String nonTerminal : rhsNonTerminals)
			if (!previousColumn.get(nonTerminal).contains("epsilon"))
				allEpsilon = false;
		if (allEpsilon) {
			concatenation.add(Objects.requireNonNullElse(rhsTerminal, "epsilon"));
		}

		while (step < rhsNonTerminals.size()) {
			boolean thereIsOneEpsilon = false;
			for (String s : previousColumn.get(rhsNonTerminals.get(step)))
				if (s.equals("epsilon"))
					thereIsOneEpsilon = true;
				else
					concatenation.add(s);
			if (thereIsOneEpsilon)
				step++;
			else
				break;
		}

		return toSet(concatenation);
	}

	private ArrayList<String> firstOfSequence(ArrayList<String> rhs) {
		ArrayList<String> result = new ArrayList<>();
		ArrayList<String> rhsNonTerminals = new ArrayList<>();
		String terminal = null;
		if (this.grammar.getTerminals().contains(rhs.get(0))) {
			result.add(rhs.get(0));
			return result;
		} else {
			for (String s : rhs) {
				if (this.grammar.getNonTerminals().contains(s))
					rhsNonTerminals.add(s);
				else {
					terminal = s;
					break;
				}
			}
		}
		return multipleConcatenation(this.first, rhsNonTerminals, terminal);
	}
	

	private ArrayList<String> toSet(ArrayList<String> var) {
		ArrayList<String> set = new ArrayList<>();
		for (String s : var)
			if (!set.contains(s))
				set.add(s);
		return set;
	}


}
