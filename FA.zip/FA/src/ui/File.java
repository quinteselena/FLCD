package ui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public abstract class File {

	public List<String> loadLines(String inFileName) throws FileNotFoundException {
		List<String> res = new LinkedList<>();
		
		BufferedReader in = createBufferedReader(inFileName);
		try {
		try {
			String line = "";
			while( (line = in.readLine()) != null) {
				res.add(line);
			}
		} finally {
			in.close();
		}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		
		return res;
	}

	public abstract BufferedReader createBufferedReader(String inFileName) 
			throws FileNotFoundException;

	public void saveToFile(List<String> lines, String outFileName) {
		try {
			BufferedWriter out = createBufferedWriter(outFileName);
			try {
				for(String line: lines) {
					out.write(line);
					out.newLine();
				}
			} finally {
				out.close();
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public abstract BufferedWriter createBufferedWriter(String outFileName) 
			throws IOException;

}