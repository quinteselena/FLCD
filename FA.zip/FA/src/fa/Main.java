package fa;

import java.io.IOException;

class Main {

	private final static Menu m = new Menu();

	public static void main(String[] args) throws IOException {
		FA FA = new FA("program.txt");
		FA.readFromFile();

		while (true) {
			System.out.println("Just behind is shown the menu:");
			m.show();
			System.out.println("Please, write your option: ");
			char option = m.readOption();

			switch (option) {
			case 'Q':
				System.out.println("SET OF STATES: ");
				System.out.println(FA.getStates());
				System.out.println();
				break;
			case 'A':
				System.out.println("INPUT SYMBOLS: ");
				System.out.println(FA.getAlphabet());
				System.out.println();
				break;
			case 'F':
				System.out.println("FINAL STATES: ");
				System.out.println(FA.getFinalStates());
				System.out.println();
				break;
			case 'T':
				System.out.println("TRANSITIONS: ");
				System.out.println(FA.getTransitions());
				System.out.println();
				break;
			case 'I':
				System.out.println("INITIAL STATE: ");
				System.out.println(FA.getStates().get(0));
				System.out.println();
				break;
			case 'D':
				if (FA.FAisDFA()) {
					System.out.println("The FA is a DFA");
				} else {
					System.out.println("The FA is NOT a DFA");

				}
				System.out.println();
				break;
			case 'V':
				if (!FA.FAisDFA()) {
					System.out.println("Please, insert another FA");
					break;
				}
				System.out.println("Enter the desire sequence: ");
				String seq = m.readString();
				if (FA.isAccepted(seq)) {
					System.out.println("ACCEPTED");
				}else {
					System.out.println("REJECTED");
				}
				System.out.println();
				break;
			case 'O':
				System.out.println("See you soon. ");
				System.exit(0);
			default:
				System.err.println("Please, try again");
				break;
			}
		}
	}

}
