package fa;

public class Menu {
	
	
	private String[] options = {
			"Q - set of all states ",
			"A - set of input symbols. ",
			"F - set of final state",
			"T - Transition Function",
			"I - Initial State",
			"O - Exit "
		};
		
	public char readOption() {
		return Console.readChar(" Option ");
	}

	public void show() {
		for(String line: options) {
			if ( "".equals(line) ) {
				Console.println("");
				continue;
			}
			Console.printf("\t%s\n", line);

		}
	}

}