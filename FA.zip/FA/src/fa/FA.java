package fa;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;



public class FA {

	private List<String> finalStates;

	private List<String> alphabet;

	private List<Transition> trasitions;

	private String nameOfFile;

	private List<String> states;
	
	private String t= "";
	
	private boolean continueReading = true;
	
	File f;
	Scanner s;
	



	public FA(String fileName) {

		this.finalStates = new ArrayList<String>();

		this.alphabet = new ArrayList<String>();

		this.trasitions = new ArrayList<Transition>();

		this.nameOfFile = fileName;

		this.states = new ArrayList<String>();
		
		f= new File(this.nameOfFile);

	}
	

	//GETTERS
		public List<String> getStates() {return states;}
		public List<String> getAlphabet() {return alphabet;}
		public List<Transition> getTransitions() {return trasitions;}
		public List<String> getFinalStates() {return finalStates;}
		
		
	public void readFromFile() throws FileNotFoundException {
		s = new Scanner(f);
		
		readStates(s);
		readAlphabet(s);
		
		String transition_t = s.nextLine();
        t = "";
     

		while (continueReading) {
			t = s.nextLine();
			// we check if it is a final state to finish going through the word or not
			if (t.equals("FINAL STATE/S")) {break;}

			List<String> transitions = Arrays.asList(t.split(","));
			Transition tr = new Transition();

			
			tr.setInitialState(transitions.get(0));
			tr.setIntermediateState(transitions.get(1));

			
			List<String> endStates = new ArrayList<String>();
			
			//we initialize i as 2 in order to show only the arrived state
			for (int i = 2; i < transitions.size(); i++) {endStates.add(transitions.get(i));}
			tr.setEndState(endStates);
			this.trasitions.add(tr);
		}

		String finalStates = s.nextLine();
		this.finalStates = Arrays.asList(finalStates.split(","));

		s.close();
	}

	private List<String> readStates(Scanner s) {
		String setStates_t = s.nextLine();
		String setOfStates = s.nextLine();
	    return this.states = Arrays.asList(setOfStates.split(","));
	}

	private  List<String> readAlphabet(Scanner s) {
		String alphabet_t = s.nextLine();
		String alphabet = s.nextLine();
		return this.alphabet = Arrays.asList(alphabet.split(","));
	}



	public class Transition {
		private String startState;
		private String intermediateState;
		private List<String> endState;

		public Transition() {}

		public void setInitialState(String startState) {this.startState = startState;}
		public void setIntermediateState(String value) {this.intermediateState = value;}
		public void setEndState(List<String> endState) {this.endState = endState;}

		@Override
		public String toString() {
			return "S(" + startState + "," + intermediateState + ") = " + endState + "\n";
		}
	}
}
