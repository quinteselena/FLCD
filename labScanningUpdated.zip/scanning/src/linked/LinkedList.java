package linked;

import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

public class LinkedList<T> {
	private Node<T> head;
	private int numberOfElements;

	@SuppressWarnings("hiding")
	class Node<T> {
		T value;
		Node<T> next;

		Node(T value, Node<T> next) {
			this.value = value;
			this.next = next;
		}
	}

	public int size() {
		return numberOfElements;
	}

	public boolean isEmpty() {
		if (numberOfElements == 0) {
			return true;
		}
		return false;
	}

	public boolean contains(T o) {

		if (isEmpty() || o == null) {
			return false;
		} else if (indexOf(o) >= 0) {
			return true;
		}
		return false;

	}

	public boolean add(T element) {

		ArgumentChecks.issTrue(element != null, "Element must not be null");

		if (isEmpty())
			addFirst(element);
		else {
			Node<T> last = obtainNode(size() - 1);
			last.next = new Node<T>(element, null);
			this.numberOfElements++;
		}
		return false;
	}

	private Node<T> obtainNode(int index) {

		int position = 0;
		Node<T> node = this.head;
		while (position < index) {
			node = node.next;
			position++;
		}
		return node;
	}

	public void addFirst(T value) {
		head = new Node<>(value, head);
		numberOfElements++;

	}

	public boolean remove(T o) {

		ArgumentChecks.issTrue(o != null, "ERROR!!");

		if (!contains(o) || o == null) {
			return false;
		}

		int pos = indexOf(o);
		if (pos >= 0) {
			remove(pos);
			return true;
		}
		return false;

	}

	public void clear() {
		head = null;
		numberOfElements = 0;

	}

	public T get(int index) {
		ArgumentChecks.issTrueBound(index >= 0 && index < size(), "ERROR");
		return (T) obtainNode(index).value;
	}

	public T set(int index, T element) {
		ArgumentChecks.issTrueBound(index >= 0 && index < size(), "ERROR");
		ArgumentChecks.issTrue(element != null, "ERROR");
		T aux = obtainNode(index).value;
		obtainNode(index).value = element;
		return aux;

	}

	public void add(int index, T element) {

		ArgumentChecks.issTrueBound(index >= 0 && index <= size(), "ERROR");
		ArgumentChecks.issTrue(element != null, "error");

		if (head == null && index > 0) {
			throw new IndexOutOfBoundsException();
		}
		if (index == 0)
			addFirst(element);
		else {
			Node<T> previous = obtainNode(index - 1);
			previous.next = new Node<T>(element, previous.next);
			this.numberOfElements++;
		}

	}

	public T remove(int index) {
		ArgumentChecks.issTrueBound(index >= 0 && index < size(), "ERROR");
		if (this.isEmpty()) {
			return null;
		}
		T value;
		if (index == 0) {
			value = this.head.value;
			this.head = this.head.next;
		} else {
			Node<T> previous = obtainNode(index - 1);
			value = previous.next.value;
			previous.next = previous.next.next;
		}
		this.numberOfElements--;
		return value;

	}

	public int indexOf(Object o) {
		Node<T> n = head;
		int i = 0;
		ArgumentChecks.issTrue(o != null, "ERROR");
		while (n != null && !n.value.equals(o)) {
			n = n.next;
			i++;
		}
		if (i == size()) {
			return -1;
		}
		return i;

	}


	public String toString() {
		String aux = "";
		Node<T> n = head;
		Node<T> last = obtainNode(size() - 1);
		while (n != null) {
			if (n == last) {
				aux += n.value;
			} else
				aux += n.value + ", ";

			n = n.next;
		}
		return "[" + aux + "]";
	}


	public int hashCode() {
		int hashCode = 1;
		for (int i = 0; i < size(); i++) {
			hashCode = 31 * hashCode + (get(i) == null ? 0 : get(i).hashCode());
		}
		return hashCode;

	}

	
	public boolean equals(Object o) {
		if (!(o instanceof List)) {
			return false;
		}
		List<?> list = (List<?>) o;

		if (list.size() != size()) {
			return false;
		}
		if (list.size() == 0 && size() == 0) {
			return true;
		}
		for (int i = 0; i < size(); i++) {
			if (!(get(i).equals(list.get(i)))) {
				return false;
			}
		}
		return true;

	}

	public Iterator<T> iterator() {
		return new LinkedListIterator(this);
	}

	public class LinkedListIterator implements Iterator<T> {

		private Node<T> n;

		public LinkedListIterator(LinkedList<T> list) {
			this.n = list.head;

		}

		@Override
		public boolean hasNext() {
			return n != null;

		}

		@Override
		public T next() {
			if (hasNext()) {
				T o = n.value;
				n = n.next;
				return o;
			}
			throw new NoSuchElementException();
		}

	}

}
