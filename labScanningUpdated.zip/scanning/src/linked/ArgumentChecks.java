package linked;

import java.util.EmptyStackException;

public class ArgumentChecks {
	public static void issTrue(boolean cond, String warning) {
		if (cond != true) {
			throw new IllegalArgumentException(warning);
		}
	}

	public static void issTrueBound(boolean cond, String warning) {
		if (cond != true) {
			throw new IndexOutOfBoundsException(warning);
		}
	}

	public static void issTrueNull(boolean cond, String warning) {
		if (cond != true) {
			throw new NullPointerException(warning);
		}
	}

	public static void issTrueEmpty(boolean cond) {
		if (cond != true) {
			throw new EmptyStackException();
		}
	}

	public static void issTrueEmptyQueue(boolean cond) throws Exception {
		if (cond != true) {
			throw new Exception();
		}
	}

}
