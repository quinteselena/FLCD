package hashTables;

import java.util.ArrayList;

public class HashTable<T> {
	protected final static int LINEAR_PROBING = 0;
	protected final static int QUADRATIC_PROBING = 1;
	protected final static int DOUBLE_HASHING = 2;
	private int B;
	private int R;
	private int redispersionType;
	private double minLF;
	private ArrayList<HashNode<T>> associativeArray;
	private int elements;

	public HashTable(int B, int redispersionType, double minLF) {
		if (B <= 0)
			throw new RuntimeException("Invalid B");
		if (redispersionType < LINEAR_PROBING || redispersionType > DOUBLE_HASHING)
			throw new RuntimeException("Invalid redispersionType");
		if (minLF < 0.00 || minLF > 1.00)
			throw new RuntimeException("Invalid minLF");
		this.B = isPrime(B) ? B : getNextPrimeNumber(B);
		this.R = getPrevPrimeNumber(B);
		this.redispersionType = redispersionType;
		this.minLF = minLF;
		this.elements = 0;
		associativeArray = new ArrayList<HashNode<T>>(this.B);
		for (int i = 0; i < this.B; i++) {
			associativeArray.add(new HashNode<>());
		}
	}

	/**
	 * Hashing function
	 *
	 * @param element to be stored.
	 * @param i       Attempt number.
	 * @return slot in the array where the element should be placed
	 */
	protected int f(T element, int i) {
		switch (redispersionType) {
		case LINEAR_PROBING:
			return ((Math.abs(element.hashCode()) + i) % B);
		case QUADRATIC_PROBING:
			return ((Math.abs(element.hashCode()) + i * i) % B);
		case DOUBLE_HASHING:
			int x = Math.abs(element.hashCode());
			int h = R - (x % R);
			return (x + i * h) % B;
		}
		return -1;
	}

	/**
	 * Method that prints the hash table
	 */
	public void print() {
		System.out.println(toString());
	}

	/**
	 * Method that returns the hash table
	 */
	public String toString() {
		String aux = "";
		for (int i = 0; i < B; i++) {
			aux += "[" + i + "] " + "(" + associativeArray.get(i).getStatus() + ") " + "= "
					+ associativeArray.get(i).getElement() + " - ";
		}
		return aux;
	}

	/**
	 * Method that returns the load factor
	 * 
	 * @return the LF
	 */
	public double getLF() {
		return (double) elements / B;
	}

	/**
	 * Method that resize the hash table
	 */
	protected void dynamicResize() {
		dynamicResize(getNextPrimeNumber(B * 2));
	}

	/**
	 * Auxiliary method to resize the hash table
	 * 
	 * @param newSize
	 */
	protected void dynamicResize(int newSize) {
		if (newSize <= B)
			throw new RuntimeException("Invalid size");
		ArrayList<HashNode<T>> aux = associativeArray; // reference to the array
		B = newSize; // change B to the new size
		R = getPrevPrimeNumber(B); // change R to the prev prime
		elements = 0; // reset the elements
		associativeArray = new ArrayList<>(B); // create a new array
		for (int i = 0; i < this.B; i++) {
			associativeArray.add(new HashNode<>()); // add the nodes
		}
		for (HashNode<T> node : aux) {
			if (node.getStatus() == HashNode.VALID)
				add(node.getElement()); // add the old nodes
		}
	}

	/**
	 * Method that adds an element in the hash table
	 * 
	 * @param element
	 */
	public void add(T element) {
		if (elements == B)
			throw new RuntimeException("Full!!!");
		for (int i = 0; i < 20000; i++) {
			int slot = f(element, i);
			HashNode<T> aux = associativeArray.get(slot);
			if (aux.getStatus() != HashNode.VALID) {
				aux.setElement(element);
				aux.setStatus(HashNode.VALID);
				elements++;
				if (getLF() > minLF)
					dynamicResize();
				return;
			}
		}
		throw new RuntimeException("Fail!!!");
	}

	/**
	 * Method that search for a valid element in the hash table
	 * 
	 * @param element
	 * @return true if there exists the element, false otherwise
	 */
	public boolean search(T element) {
		for (int i = 0; i < 20000; i++) {
			int slot = f(element, i);
			HashNode<T> aux = associativeArray.get(slot);
			if (aux.getStatus() == HashNode.VALID) {
				if (element.equals(aux.getElement()))
					return true;
				else if (aux.getStatus() == HashNode.EMPTY) {
					return false;
				}
			}
		}
		return false;
	}

	/**
	 * Method that change the status of the element to DELETE aka remove the element
	 * 
	 * @param element
	 */
	public void remove(T element) {
		for (int i = 0; i < 20000; i++) {
			int slot = f(element, i);
			HashNode<T> aux = associativeArray.get(slot);
			if (aux.getStatus() == HashNode.VALID) {
				if (element.equals(aux.getElement())) {
					aux.setStatus(HashNode.DELETED);
					elements--;
				} else if (aux.getStatus() == HashNode.EMPTY)
					return;
			}
		}
	}

	/**
	 * Method to know if a number is prime or not
	 * 
	 * @param number
	 * @return true if a number is prime, false otherwise
	 */
	public boolean isPrime(int number) {
		if (number <= 1) {
			return false;
		}
		for (int i = 2; i <= Math.sqrt(number); i++) {
			if (number % i == 0) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Method that returns the previous prime number for a input number
	 * 
	 * @param number
	 * @return the previous prime number
	 */
	public int getPrevPrimeNumber(int number) {
		do {
			number--;
		} while (number > 2 && !isPrime(number));
		if (number < 2)
			return 2;
		return number;
	}

	/**
	 * Method that returns the next prime number for a input number
	 * 
	 * @param number
	 * @return the next prime number
	 */
	public int getNextPrimeNumber(int number) {
		do {
			number++;
		} while (!isPrime(number));
		return number;
	}
}
