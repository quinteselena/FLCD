package scanning;

import java.io.FileNotFoundException;
import java.util.List;

import ui.File;
import ui.FileUtil;

public class Main {

	private static final String MODEL_FILE = "program.txt";
	//private static final String RESULT_FILE = "result.txt";

	public static void main(String[] args) {
		new Main().run();
	}

	private void run() {
		try {
			execute();
		} catch (RuntimeException e) {
			handleSystemError(e);
		} catch (Exception e) {
			handleAppError(e);
		}
		// add default exception handlers here
	}

	private void handleAppError(Exception e) {
		String msg = "An error has happened. Please mind it and try again.\n" + e.getMessage();
		System.out.println(msg);
	}

	private void handleSystemError(RuntimeException e) {
		String msg = "A severe error has happened. The programs must stop.\n" + "Please contact the technical staff";

		System.out.println(msg);
		Logger.log(e.getMessage());
		Logger.log(e);
	}

	private void execute() throws FileNotFoundException {
		FileUtil f = new FileUtil();
		Parser p = new Parser();
		List<String> l = f.loadLines(MODEL_FILE);
		p.parse(l);
	}



}
