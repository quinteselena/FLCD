package scanning;

public class Logger {

	public static void log(Exception e) {
		e.printStackTrace();
	}

	public static void log(String msg) {
		System.err.println( msg );
	}

}
