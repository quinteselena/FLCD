package scanning;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Parser {

	// preguntar si solo identifiers son los que no se repiten

	private int lineNumber;

	private List<String> identifiers = new ArrayList<>();

	private List<String> operators = Arrays.asList("+", "++", "-", "--", "*", "/", ":=", "<", "<=", "=", ">=", "&&",
			"||");

	private List<String> separators = Arrays.asList(" ", ";", "[", "]", "{", "}", ";", " ", ",", "(", ")");

	private List<String> reserved = Arrays.asList("char", "const", "do", "else", "if", "int", "of", "program", "read",
			"while", "begin", "end", "then", "var", "write", "for", "def", "print", "return", "array", "and", "elif");

	private String[] num_list = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };

	private List<String> alphabet = Arrays.asList("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n",
			"o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z");

	public List<String> parse(List<String> lines) {
		List<String> res = new LinkedList<>();
		lineNumber = 0;
		for (String line : lines) {
			if (line.trim().isEmpty())
				continue;
			try {
				List<String> p = splitBySeparator(line);
				for (String word : p) {
					res.add(word);
				}

			} catch (InvalidLineFormatException e) {
				Logger.log(e.getMessage() + lineNumber);
			}
			lineNumber++;
		}

		print(res);
		printST(identifiers);

		return identifiers;
	}

	private void print(List<String> res) {

		for (int i = 0; i < res.size(); i++) {
			if (isConstant(res.get(i))) {
				System.out.println(res.get(i) + " -1");
			}
			if (isOperator(res.get(i))) {
				System.out.println(res.get(i) + " -1");
			}
			if (isSeparator(res.get(i))) {
				System.out.println(res.get(i) + " -1");
			}

			isNotLexicalError(res.get(i));

		}
	}

	private void printST(List<String> x) {

		System.out.println();
		System.out.println();
		System.out.println("SYMBOL TABLE");

		for (int i = 0; i < x.size(); i++) {
			System.out.println(x.get(i) + "(" + i + ")");
		}

	}

	private List<String> splitBySeparator(String line) throws InvalidLineFormatException {
		List<String> x = null;

		for (int i = 0; i < separators.size(); i++) {
			if (line.contains(separators.get(i))) {
				x = Arrays.asList(line.split(separators.get(i)));
				break;
			}
		}
		return x;
	}

	private void isNotLexicalError(String x) {

		startsWithOperatorOrSeparator(x);

		startsWithNumber(x);

		isAnIdentifier(x);
		
		isValidIdentifier(x);

	}

	private void isAnIdentifier(String x) {

		// identifies the constants which are numeric
		for (int i = 0; i < num_list.length; i++) {
			if (x.length() == 1 && num_list[i].contains(String.valueOf(x))) {
				if (!identifiers.contains(x)) {
					identifiers.add(x);
					System.out.println(x + "  Constant");
				}
			}
		}

		// identifies the constants between quotes
		for (int i = 0; i < x.length(); i++) {
			if (x.startsWith("'") && x.endsWith("'")) {
				if (!identifiers.contains(x)) {
					identifiers.add(x);
					System.out.println(x + "  Constant");
				}

			}
		}

	}

	private void isValidIdentifier(String x) {
		// identifies the id
		int counter = x.length();
		for (int j = 0; j < x.length(); j++) {
			if (!isConstant(x)) {
				for (int i = 0; i < alphabet.size(); i++) {
					if (String.valueOf(x.charAt(j)).contains(alphabet.get(i))) {
						counter--;
					}
				}
			}

			if (counter == 0) {
				if (!identifiers.contains(x)) {
					identifiers.add(x);
					System.out.println(x);
				}
			}
		}
	}

	private void startsWithNumber(String x) {
		for (int i = 0; i < num_list.length; i++) {
			if (num_list[i].contains(String.valueOf(x.charAt(0))) && x.length() > 1) {
				System.out.println(x + " Lexical error");

			}
		}
	}

	private void startsWithOperatorOrSeparator(String x) {
		if (isOperator(String.valueOf(x.charAt(0))) && x.length() > 1
				|| isSeparator(String.valueOf(x.charAt(0))) && x.length() > 1) {
			System.out.println(x + " Lexical error");

		}
	}

	private boolean isOperator(String x) {
		for (int i = 0; i < operators.size(); i++) {
			if (operators.get(i).equals(x)) {
				return true;
			}
		}
		return false;
	}

	private boolean isConstant(String x) {
		for (int i = 0; i < reserved.size(); i++) {
			if (reserved.get(i).equals(x)) {

				return true;
			}
		}
		return false;
	}

	private boolean isSeparator(String x) {
		for (int i = 0; i < separators.size(); i++) {
			if (separators.get(i).equals(x)) {
				return true;
			}
		}
		return false;
	}

}
