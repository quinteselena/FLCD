package scanning;


@SuppressWarnings("serial")
public class InvalidLineFormatException extends Exception {
	
	private int lineNumber;
	
	public InvalidLineFormatException(int lineNumber) {
		this.lineNumber = lineNumber;
	}

	public InvalidLineFormatException(int lineNumber, String arg0) {
		super(arg0);
		this.lineNumber = lineNumber;
	}

	public InvalidLineFormatException(int lineNumber, Throwable arg0) {
		super(arg0);
		this.lineNumber = lineNumber;
	}

	public InvalidLineFormatException(int lineNumber, String arg0, Throwable arg1) {
		super(arg0, arg1);
		this.lineNumber = lineNumber;
	}

	public InvalidLineFormatException(int lineNumber, String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		this.lineNumber = lineNumber;
	}

	public InvalidLineFormatException(String arg0) {
		super(arg0);	
	}

	@Override
	public String getMessage() {
		return "The line" + lineNumber + " " + super.getMessage();
	}

 
}
